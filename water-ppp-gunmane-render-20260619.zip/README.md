# Water PPP / Gunmane Map for Render

Render Static Site 用のファイル一式です。

- `index.html`: アプリ本体
- `render.yaml`: Render Blueprint 設定

Renderで使う場合は、このフォルダの中身をGitHub等のリポジトリに置き、Static Siteとして公開してください。
Publish directory は `.` です。
